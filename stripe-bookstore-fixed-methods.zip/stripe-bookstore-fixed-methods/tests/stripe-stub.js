const Module = require('node:module');
const load = Module._load;

Module._load = function (request, parent, isMain) {
  const result = load.call(this, request, parent, isMain);
  if (request !== 'stripe') return result;

  return (key, options) => result(key, {
    ...options,
    host: '127.0.0.1',
    port: Number(process.env.STRIPE_STUB_PORT),
    protocol: 'http',
    maxNetworkRetries: 0,
  });
};
