const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const net = require('node:net');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { once } = require('node:events');
const Stripe = require('stripe');

async function unusedPort() {
  const server = net.createServer();
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  await new Promise(resolve => server.close(resolve));
  return port;
}

test('fixed payment methods and payment status pages', async t => {
  const requests = [];
  let failCreate = false;
  const stripeStub = http.createServer((req, res) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      requests.push({ path: req.url, body, version: req.headers['stripe-version'] });
      res.setHeader('content-type', 'application/json');
      if (req.method === 'POST' && req.url === '/v1/payment_intents') {
        if (failCreate) {
          res.statusCode = 400;
          return res.end(JSON.stringify({ error: { type: 'invalid_request_error', message: 'Simulated failure' } }));
        }
        return res.end(JSON.stringify({
          id: 'pi_test', object: 'payment_intent',
          client_secret: 'pi_test_secret_placeholder',
        }));
      }

      const id = new URL(req.url, 'http://localhost').pathname.split('/').pop();
      const status = {
        pi_success: 'succeeded',
        pi_processing: 'processing',
        pi_action: 'requires_action',
        pi_failed: 'requires_payment_method',
      }[id];
      if (!status) {
        res.statusCode = 404;
        return res.end(JSON.stringify({ error: { type: 'invalid_request_error', message: 'Not found' } }));
      }
      res.end(JSON.stringify({
        id, object: 'payment_intent', status,
        amount: 2500, amount_received: status === 'succeeded' ? 2500 : 0,
        currency: 'usd', metadata: { book_title: 'Test book' }, latest_charge: null,
      }));
    });
  });
  await new Promise(resolve => stripeStub.listen(0, '127.0.0.1', resolve));

  const port = await unusedPort();
  const app = spawn(process.execPath, ['--require', path.join(__dirname, 'stripe-stub.js'), 'app.js'], {
    cwd: path.join(__dirname, '..'),
    env: {
      ...process.env,
      PORT: String(port),
      STRIPE_STUB_PORT: String(stripeStub.address().port),
      STRIPE_SECRET_KEY: 'sk_test_fake',
      STRIPE_PUBLISHABLE_KEY: 'pk_test_fake',
      STRIPE_WEBHOOK_SECRET: 'whsec_fake',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let appOutput = '';
  app.stdout.on('data', chunk => { appOutput += chunk; });
  app.stderr.on('data', chunk => { appOutput += chunk; });
  t.after(async () => {
    if (app.exitCode === null) {
      app.kill('SIGTERM');
      await once(app, 'exit');
    }
    await new Promise(resolve => stripeStub.close(resolve));
  });

  const base = `http://127.0.0.1:${port}`;
  let ready = false;
  for (let i = 0; i < 50; i++) {
    if (app.exitCode !== null) throw new Error(`App exited early: ${appOutput}`);
    try {
      const response = await fetch(base);
      if (response.ok) { ready = true; break; }
    } catch (error) {
      if (error.cause?.code !== 'ECONNREFUSED') throw error;
    }
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  assert.ok(ready, `App did not start: ${appOutput}`);

  const create = await fetch(`${base}/create-payment-intent`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ item: '2', amount: 1 }),
  });
  assert.equal(create.status, 200);
  assert.equal((await create.json()).clientSecret, 'pi_test_secret_placeholder');
  const sent = new URLSearchParams(requests[0].body);
  assert.equal(sent.get('amount'), '2500');
  const methods = [...sent].filter(([name]) => /^payment_method_types\[\d+\]$/.test(name)).map(([, value]) => value);
  assert.deepEqual(methods,
    ['card', 'link', 'us_bank_account', 'cashapp']);
  assert.equal(sent.get('automatic_payment_methods[enabled]'), null);
  assert.equal(requests[0].version, '2024-06-20');

  const invalid = await fetch(`${base}/create-payment-intent`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ item: '9' }),
  });
  assert.equal(invalid.status, 400);
  assert.equal(requests.length, 1);

  failCreate = true;
  const rejected = await fetch(`${base}/create-payment-intent`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ item: '2' }),
  });
  assert.equal(rejected.status, 500);
  assert.match((await rejected.json()).error.message, /payment method settings/);
  failCreate = false;

  for (const [id, label, heading] of [
    ['pi_success', 'Total charged', 'Success!'],
    ['pi_processing', 'Order total', 'Payment processing'],
    ['pi_action', 'Order total', 'Payment action required'],
    ['pi_failed', 'Order total', 'Payment not completed'],
  ]) {
    const response = await fetch(`${base}/success?payment_intent=${id}`);
    const html = await response.text();
    assert.equal(response.status, 200);
    assert.ok(html.includes(label));
    assert.ok(html.includes(heading));
    if (id !== 'pi_success') assert.ok(!html.includes('Total charged'));
    assert.ok(html.includes('$25.00'));
  }

  const payload = JSON.stringify({
    type: 'payment_intent.succeeded',
    data: { object: { id: 'pi_test', amount: 2500, currency: 'usd', metadata: { book_id: '2' } } },
  });
  const signature = Stripe('sk_test_fake').webhooks.generateTestHeaderString({ payload, secret: 'whsec_fake' });
  for (const [header, expected] of [[signature, 200], ['invalid', 400]]) {
    const response = await fetch(`${base}/webhook`, {
      method: 'POST', headers: { 'content-type': 'application/json', 'stripe-signature': header }, body: payload,
    });
    assert.equal(response.status, expected);
  }
});
