# Stripe bookstore: Stripe Element with fixed payment methods

This is a **separate version** of the Stripe Payment Element bookstore.
It demonstrates an older, exactly pinned Stripe Node SDK and a fixed list of payment methods. The main Payment Element submission remains unchanged.


In `app.js`, the PaymentIntent  contains:

```javascript
payment_method_types: ['card', 'link', 'us_bank_account', 'cashapp']
```

We no longer send `automatic_payment_methods`. The four entries mean:

- **Card:** credit or debit card.
- **Link:** Stripe's faster checkout using saved payment details.
- **US bank account:** ACH Direct Debit from a US bank account. It can take days to complete and may require bank verification.
- **Cash App Pay:** a US digital wallet.

This is a fixed list in the server code


## How to run on a Mac

1. Download the ZIP to **Downloads** and double-click it. The folder should be named `stripe-bookstore-fixed-methods`.
2. Open **Terminal**. Copy each command below, press **Enter**, and wait for it to finish:

   ```bash
   cd ~/Downloads/stripe-bookstore-fixed-methods
   ```

3. Check that you are in the right folder:

   ```bash
   ls
   ```

   The list should include `package.json`.

4. Check Node.js and install the app's packages. Node.js **20 or later** is required.

   ```bash
   node --version
   ```

   ```bash
   npm install
   ```

5. Create the settings file and open it:

   ```bash
   cp -n sample.env .env
   ```

   ```bash
   open -e .env
   ```

6. In the file that opens, replace the placeholders with the **test secret key and test publishable key from the same eligible US sandbox**:

   ```text
   STRIPE_SECRET_KEY=sk_test_your_key_here
   STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
   ```

   Get them from the sandbox's [API keys page](https://dashboard.stripe.com/test/apikeys). Save with **Command + S** and close the file. `cp -n` does not overwrite an existing `.env`.

7. Start the app:

   ```bash
   npm start
   ```

8. Leave Terminal running and open **http://localhost:3000**. Choose a book. On the payment page, Stripe displays the options eligible for that sandbox and transaction.
9. To try a card payment, enter an email and Stripe's test card **4242 4242 4242 4242**, with a future expiry such as **12/34**, CVC **123**, and any requested test address details. After a successful payment, the confirmation shows the amount and a `pi_...` PaymentIntent ID. No real money is moved with test keys.



## How the app works
1. Select a book. The home page links to /checkout?item=<id>

2. Look up the price. The server gets the book and its amount from lib/catalog.js. The browser sends the book ID, not a price, so changing a displayed browser value cannot choose the amount charged.

3. Create a PaymentIntent. The checkout page sends the selected book ID to POST /create-payment-intent. The server creates a PaymentIntent using the server-side amount, usd, a book description and metadata, and the four fixed payment types. Stripe returns a client secret for the payment form.

4. Show the Payment Element. public/js/checkout.js loads Stripe.js, initializes Elements with the client secret and mounts the payment form into the page.

5. Confirm payment. When the customer presses Pay, the browser calls stripe.confirmPayment(). Stripe handles card validation and any needed authentication, such as 3D Secure. The browser does not send raw card numbers to the bookstore server.

6. Show the result. Stripe returns the browser to /success?payment_intent=pi_.... The server retrieves that PaymentIntent from Stripe and uses Stripe's recorded status and amount. It says Total charged only when status is succeeded; a pending, action-required or incomplete payment is labelled Order total instead.

7.Receive payment events. If configured, /webhook verifies Stripe's signature against the exact raw request body and logs succeeded or failed PaymentIntent events. This demo does not update an order, send email, or ship a book.

8.Stripe will handle the payment information in the Payment Element; raw card details are not sent to this server. 




### Reference Files

| File | Purpose |
|---|---|
| `package.json`, `package-lock.json` | Pin and record the older Stripe Node SDK |
| `app.js` | API version, fixed payment method list, server routes, and webhook |
| `lib/catalog.js` | Books and server-side prices |
| `views/checkout.hbs`, `public/js/checkout.js` | Checkout page and Stripe Payment Element |
| `views/success.hbs` | Payment result and amount labels |
| `tests/` | Offline tests for the fixed request and payment status pages |

The homepage also has display prices in `views/index.hbs`, separate from `lib/catalog.js`. Update both if changing prices in this demo.


```


### Architecture


Browser: choose book
    │
    ▼
Express app (app.js) ─── looks up book and price ─── lib/catalog.js
    │
    ├── creates PaymentIntent with fixed payment methods ──▶ Stripe API
    │◀── returns client secret ──────────────────────────────┘
    │
    ▼
Stripe.js displays Payment Element in the browser
    │ customer confirms
    ▼
Stripe processes payment ── redirects browser to /success
    │                              │
    │ sends payment webhook        └── Express retrieves PaymentIntent
    ▼
Express /webhook logs event             │
                                        ▼
                              success page shows status and amount





