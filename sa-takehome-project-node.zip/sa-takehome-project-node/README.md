<<<<<<< HEAD
# Stripe Press Shop with the Stripe Payment Element
## This code use Automatic payment methods enabled in the Stripe Dashboard

A small Node.js/Express store that sells three Stripe Press books. 
A customer can:

1. **Select a book** on the home page.
2. **Check out and pay** with the embedded **Stripe Payment Element** (not Stripe Checkout).
3. **See a confirmation page** showing the **total charged** and the **PaymentIntent ID** (`pi_...`).

The project starts from the shared boilerplates at [`sa-takehome-project-node`](https://github.com/mattmitchell6/sa-takehome-project-node) boilerplate. I used the same structure and added the payment flow.

---

## 1. Build, configure and run

### Prerequisites

- **Node.js 20 or later** (server checked with Node 26) and npm
- A **Stripe account** in test mode. 

### Install

```bash
cd sa-takehome-project-node
npm install
```

### Configure

Copied the sample environment file and added the **test-mode** keys from (https://dashboard.stripe.com/test/apikeys):

```bash
cp sample.env .env


### Run

```bash
npm start
```

Open **http://localhost:3000**.

### Try a payment

Choose a book, enter any email address, and pay with one of Stripe's [test cards] at
(https://stripe.com/docs/testing) 

| Scenario | Card number |
|---|---|
| Successful payment | `4242 4242 4242 4242` |
| Requires 3D Secure authentication | `4000 0025 0000 3155` |
| Declined (insufficient funds) | `4000 0000 0000 9995` |
| Generic decline | `4000 0000 0000 0002` |

After a successful payment, the confirmation page shows the book, the amount charged (for example, **$25.00**), and the **PaymentIntent ID**. You can find the same payment under [Dashboard → Payments](https://dashboard.stripe.com/test/payments). Declined cards show an inline error on the checkout page, and the customer can try again.


## 2. How the solution works
1. **Pick a book:** `/checkout?item=<id>` looks up the book in `lib/catalog.js` and renders the checkout page with the public Stripe key.

2. **Start payment safely:** `public/js/checkout.js` sends *only* the book ID to `POST /create-payment-intent`. The server looks up the real price, creates a PaymentIntent (`automatic_payment_methods: { enabled: true }`), and returns a `client_secret`—so no one can tamper with the price in the browser.

3. **Collect & confirm:** Stripe.js renders the Payment Element. Clicking Pay calls `stripe.confirmPayment()`, sending card details straight to Stripe (never touching our server), handling 3D Secure if needed, and redirecting to `/success`.

4. **Verify confirmation:** `/success` fetches the PaymentIntent directly from Stripe instead of trusting the URL, then shows the status, amount, book title, `pi_` ID, and receipt link.

5. **Webhooks (optional):** `POST /webhook` verifies Stripe's signature and logs `payment_intent.succeeded` and `payment_intent.payment_failed`.

### Payment flow

```
 Browser                                   Express server                     Stripe API
 ───────                                   ──────────────                     ──────────
 GET /checkout?item=2  ─────────────────▶  look up book in catalog
                       ◀─────────────────  render page + publishable key

 POST /create-payment-intent {item:2} ───▶  price looked up server-side
                                            paymentIntents.create(2500 usd) ─▶ PaymentIntent
                       ◀─────────────────  { clientSecret }               ◀── pi_..._secret_...
 stripe.elements({clientSecret})
 mount Payment Element (card, wallets, …)
 Pay → stripe.confirmPayment() ──────────────────────────────────────────────▶ confirm, 3DS if needed
                       ◀───────────────────────────── redirect to /success?payment_intent=pi_...
 GET /success?payment_intent=pi_... ─────▶  paymentIntents.retrieve(pi_...) ─▶ status, amount
                       ◀─────────────────  render amount + pi_ ID
                                            POST /webhook ◀──────────────────── payment_intent.succeeded
```


### Stripe APIs and products used

| Where | API | Purpose |
|---|---|---|
| Server (`stripe` Node SDK) | [`paymentIntents.create`](https://stripe.com/docs/api/payment_intents/create) | Creates the payment for the server-determined amount, with automatic payment methods and metadata |
| Server | [`paymentIntents.retrieve`](https://stripe.com/docs/api/payment_intents/retrieve) (expanding `latest_charge`) | Gets the trusted status, amount and receipt URL for the confirmation page |
| Browser ([Stripe.js](https://stripe.com/docs/js)) | `stripe.elements({ clientSecret, appearance })` and `elements.create('payment')` | Renders the [Payment Element](https://stripe.com/docs/payments/payment-element), styled to match the Bootstrap UI with the Appearance API |
| Browser | [`stripe.confirmPayment`](https://stripe.com/docs/js/payment_intents/confirm_payment) | Confirms the PaymentIntent, runs 3DS when needed, and redirects to the return URL |

### Architecture

app.js                  Server setup, page routes, Stripe calls, and webhook handler

lib/catalog.js          Book list, checkout prices, and dollar formatting

views/
  layouts/main.hbs      Shared page layout and error banner
  index.hbs             Home page (note: display prices here are still hard-coded)
  checkout.hbs          Email input + Stripe payment form container
  success.hbs           Confirmation page (amount + PaymentIntent ID)

public/js/
  checkout.js           Starts the payment, loads the form, and submits it
  custom.js             Starter helper that formats cents as dollars

sample.env              Template for API keys and optional settings

## Key decisions & status

- **The server determines the charge.**
Checkout prices come from `lib/catalog.js`, and the confirmation page reads its data from Stripe rather than from the URL. The home page also contains hard-coded display prices in `views/index.hbs`, so both places must currently be updated when a price changes.
- **Secrets stay on the server.** 
Only the publishable key is sent to the browser, and the secret key is read from `.env`.


---

## How I approached the problem

1. **Read the boilerplate.** It already had the three pages and a hard-coded price switch, so I kept that structure and limited changes to the payment flow.
2. **Chose an integration pattern.** The brief asked for the Payment Element rather than Checkout, so the solution uses Stripe's [custom integration with Elements and Payment Intents](https://docs.stripe.com/payments/advanced): create the PaymentIntent on the server, mount the Payment Element with its client secret, call `confirmPayment`, and use a return URL.
3. **Started with security.** I moved prices into a server-side catalog, sent only the item ID from the browser, and built the confirmation page from a server-side `retrieve` call.
4. **Handled common cases,** including displaying declined-payment errors and distinguishing `processing` payments, invalid item IDs, missing configuration, and missing or unknown payment references.
5. **Checked the server routes** against a local stub of the Stripe API. These checks confirmed that a price sent by the client is ignored, unknown items return errors, `/success` rejects missing or unknown PaymentIntent IDs, and webhook signatures are enforced. The browser flow has **not yet been verified with a Stripe account and test card**; run the test described above before relying on or submitting the project.

### Documentation used

- [Custom integration with Elements and Payment Intents](https://docs.stripe.com/payments/advanced)
- [Payment Element overview](https://stripe.com/docs/payments/payment-element) and [Appearance API](https://stripe.com/docs/elements/appearance-api)
- [PaymentIntents API reference](https://stripe.com/docs/api/payment_intents) and [PaymentIntent lifecycle](https://stripe.com/docs/payments/paymentintents/lifecycle)
- [`stripe.confirmPayment` reference](https://stripe.com/docs/js/payment_intents/confirm_payment)
- [Webhooks and signature verification](https://stripe.com/docs/webhooks) and [Stripe CLI `listen`](https://stripe.com/docs/stripe-cli)
- [Testing and test cards](https://stripe.com/docs/testing)

### Challenges and decisions

- **When to create the PaymentIntent.** The Payment Element needs a client secret before it can render. I created the intent when the checkout page loads. This is the simplest documented pattern, but it can leave an unused, incomplete PaymentIntent when a customer leaves the page. That has no cost, but Stripe's [deferred intent creation](https://stripe.com/docs/payments/accept-a-payment-deferred) flow avoids it and is listed as an improvement below.
- **Showing a confirmation.** The redirect URL contains the `pi_` ID, but a URL can be edited. Retrieving the PaymentIntent on the server ensures that the amount and status shown are the ones Stripe recorded.
- **Upgrading the SDK.** The boilerplate pinned `stripe@8`. I upgraded to the current Node SDK so the code uses the current API version and `automatic_payment_methods`.

**Docs referenced:** 
[Custom Elements & Payment Intents](https://docs.stripe.com/payments/advanced) 
[Payment Element](https://stripe.com/docs/payments/payment-element)
[Appearance API](https://stripe.com/docs/elements/appearance-api)
[PaymentIntents API](https://stripe.com/docs/api/payment_intents)
[confirmPayment](https://stripe.com/docs/js/payment_intents/confirm_payment)
[Webhooks](https://stripe.com/docs/webhooks) · [Test Cards](https://stripe.com/docs/testing)